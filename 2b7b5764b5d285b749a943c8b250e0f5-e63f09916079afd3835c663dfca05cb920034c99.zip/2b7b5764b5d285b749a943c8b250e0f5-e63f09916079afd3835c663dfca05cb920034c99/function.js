function voting(){
    // Program for Voting
    prompt=require('prompt-sync')();
    age=prompt("Enter your age")
    if (age>18) {
        console.log("you can vote")
    }
    else {
        console.log("you cannot vote")
    }
}

function palindrome(){
    prompt=require('prompt-sync')();
    str = prompt("Enter any name")
   // let str="rohit";
    const length=str.length;
    let flag=1
    for(let i=0; i<length/2; i++) {
        if(str[i] !== str[length-1-i]) {
            flag=0;
        }
    }
    if (flag == 1) {
        console.log("It is palindrome");
    }
    else {
        console.log("It is not palindrome");
    }
}

function timetable(){
    prompt = require('prompt-sync')();
    services = prompt("enter day name")
    switch (services) {
        case"sunday":

            console.log("7Am to 10Pm")
            break;
        case"Monday to Friday":

            console.log("9Am to 10Pm")
            break;
        default:

            console.log("closed")
    }

}
prompt=require('prompt-sync')();
program = prompt("Enter program you would like to run voting,palindrome,timetable")

if (program == "voting"){
    voting()
}
else if(program =="palindrome") {
    palindrome()
}
else if(program =="timetable") {
    timetable()
}


